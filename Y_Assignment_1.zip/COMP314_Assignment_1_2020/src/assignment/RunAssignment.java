package assignment;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

public class RunAssignment {
	public static void main(String[] args) throws IOException,ParseException {
		PrepTestCases processFile = new PrepTestCases();  // processes file
		
		ArrayList<String> regex = processFile.getRegex();  // gets the regex from the file
		ArrayList<ArrayList<String>> testCases = processFile.getTestCases();  // gets the test cases pertaining to the regex from the file
		
		for (int i = 0; i < regex.size(); i++) {  // loop for however many regex there are in the file
			System.out.println("Converting regular expression " + regex.get(i) + " to RegExp expression tree");
	        try {
	            RegExp.setNextStateNum(0);
	            RegExp r = (new RegExp2AST(regex.get(i)).convert());
	            System.out.println("No syntax errors");
	            System.out.println("Original fully parenthesised regular expression : " +
	                    r.decompile());
	            System.out.println("\nConverting regular expression " + regex.get(i) + " to NFA");
	            Nfa n = r.makeNfa();
	            SubsetConstruction s = new SubsetConstruction();
	            Dfa d = s.subsetCns(n.getStart());  // performs subsetCns on Nfa to make a Dfa
	            //System.out.println(d);  // uncomment this line to see the transition tables for each & every regex
	            for (int j = 0; j < testCases.get(i).size(); j++) {  // loop for all testCases pertaining to a particular regex
	            	if (d.D_RECOGNIZE((testCases.get(i)).get(j)))  // checks acceptance on each testCase for a perticular regex
	            		//System.out.println("The string: " + (testCases.get(i)).get(j) + " IS a member of the language denoted by the regular expression using the DFA!");
	            		System.out.println("The string: " + (testCases.get(i)).get(j) + " IS ACCEPTED");  
	            	else
	            		//System.out.println("The string: " + (testCases.get(i)).get(j) + " IS NOT member of the language denoted by the regular expression using the DFA!");
	            		System.out.println("The string: " + (testCases.get(i)).get(j) + " IS REJECTED");
	            }
	        } catch (ParseException ex) {
	        	System.out.println("Error at/near position " + ex.getErrorOffset() + " : " +
                    ex.getMessage());
        	} 
	        System.out.println();
		}
	}
}
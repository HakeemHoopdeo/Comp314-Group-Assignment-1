package assignment;  
/* This class uses the concept of Software Design principles known as Single Responsibility Principle
 * i.e. One class will have one responsibility - for example - reading from a file
 * This helps to keep our programs neater, smaller, maintainable (easier to debug, etc).
 */

import java.io.*;
import java.util.ArrayList;

/*  regexN: ArrayList<String>
 *  {  R1, R2, ..., Rn  }
 */

/*  testCases: ArrayList<ArrayList<String>>
 * R1: {  T1A, T1B, T1C,
 * R2:    T2A, T2B, T2C, T2D, T2E,
 * R3:    T3A, T3B, T3C, T3D,
 * ...
 * Rn:    TnA, TnB, TnC, ..., TnZ }
*/

/* This class prepares the test cases appropriately for processing */
public class PrepTestCases {
    private ArrayList<String> regexN = new ArrayList<>(); // List of regex
    private ArrayList<ArrayList<String>> testCases = new ArrayList<>(); // List of test cases for each regexN

    
    public PrepTestCases() throws IOException {
        File testData = new File("TestData.txt");
        try (BufferedReader br = new BufferedReader(new FileReader(testData))) {  // Using a buffered reader to read text from a character stream with efficiency
			String line = "";  // used to read text file line by line
			boolean regexLine = true;  // checks if a line has a regex to add to regexN, else, build testCases for current regexN
			ArrayList<String> testCase = new ArrayList<>();  // arraylist of testCases pertaining to each unique regex in regexN

			while ((line = br.readLine()) != null) {  // while the file isn't empty
			    if (regexLine) {  // if the line contains a regex
			        regexN.add(line);  // add the regex to the array - i.e. regexN
			        regexLine = false;
			    }
			    else {  // if the current line isn't a regex (it's either a testCase of the last element of regexN or a "//")
			        if (!line.equals("//"))  // if the current line is a testCase for the last added regex - i.e. the last element of regexN
			            testCase.add(line);  // add it to the test cases dealing with that regex
			        else {  // if the current line is a "//"
			            testCases.add(testCase);  // add the test case for that regex to the list of testCases for that regex
			            regexLine = true;  // set this to true because the line after "//" is going to be another regex if it's not null
			            testCase = new ArrayList<>();  // refresh the arraylist to get test cases for the new regex
			        }
			    }
			}
		}
    }

    public ArrayList<String> getRegex() { return regexN; }  // returns our list of regex read from the file

    public ArrayList<ArrayList<String>> getTestCases() { return testCases; }  // returns our testCases for each regex read from the file
}

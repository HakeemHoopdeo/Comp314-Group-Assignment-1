package assignment;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.*;

public class SubsetConstruction {
    LinkedHashSet<HashSet<NfaState>> dfaStates;  // set of DFA states where each DFA state contains a set of NFA states
    int[][] dTrans;  // transition table for DFA

    public SubsetConstruction() {  // crucial initialization
        dfaStates = new LinkedHashSet<>();
        dTrans = new int[Dfa.MAX_STATES][Dfa.SIGMA_UPPER];
    }

    /* e_Closure algorithm from the slides that produces a set of NfaStates on e_transitions */
    public HashSet<NfaState> e_Closure(HashSet<NfaState> T){
        HashSet<NfaState> eClosure = T;
        Stack<NfaState> stack = new Stack<NfaState>();
        for (NfaState ti: T)
            stack.push(ti);
        while (!stack.isEmpty()) {
            NfaState v = stack.pop();
            if (v.getSymbol() == NfaState.EPSILON && v.getSymbol2() == NfaState.EPSILON) {  // Are there any e_transition?
                NfaState next1 = v.getNext1();  // stores the transitions
                NfaState next2 = v.getNext2();
                if (next1 != null) {  // There are transitions (check for safety purposes)
                    eClosure.add(next1);  // Add the transitions
                    if (!stack.contains(next1))
                        stack.push(next1);
                }
                if (next2 != null){  // There are transitions (check for safety purposes)
                    eClosure.add(next2);  // Add the transitions
                    if (!stack.contains(next2))
                        stack.push(next2);
                }
            }
        }
        return eClosure;
    }

    /* Move algorithm from the slides that produces a set of NfaStates on symbol: char transitions */
    public HashSet<NfaState> Move(HashSet<NfaState> T, char symbol){
        HashSet<NfaState> move = new HashSet<>();
        for(NfaState ti: T){
        	if (ti != null) {
        		if (ti.getCharacterClass()) {  // if it's a character class
        			if (ti.getSymbol() <= symbol && symbol <= ti.getSymbol2())  // if symbol is within the character class
        				move.add(ti.getNext1());  // make the transition on that symbol 
        		}
        		else {
        			if (ti.getSymbol() == symbol)  // if there is a transition on the given symbol
        				move.add(ti.next1);  // make the transition on that symbol 
        			if (ti.getSymbol2() == symbol)  // if there is a transition on the given symbol
        				move.add(ti.next2);  // make the transition on that symbol 
        		}
        	}
        }
        return move;
    }
    
    /* Help function to be used later */
    public int getIndex(LinkedHashSet<HashSet<NfaState>> dfaStates, HashSet<NfaState> state){
        int index = 1;
        for (HashSet<NfaState> states: dfaStates) {
            if(states.containsAll(state)) 
                return index;
            index++;
        }
        return -1;
    }

    /* Subset Construction algorithm from the slides that produces a DFA from an NFA with Thompson properties */
    public Dfa subsetCns(NfaState start) {
        HashSet<NfaState> T, V;
        HashSet<NfaState> s0 = new HashSet<>();
        s0.add(start);
        Queue<HashSet<NfaState>> que = new LinkedList<>();
        V = e_Closure(s0);
        for (NfaState Vi: V) {  // Checks if initial state of the DFA had a final state of the NFA
        	if (Vi.getSymbol() == NfaState.ACCEPT || Vi.getSymbol2() == NfaState.ACCEPT) {
        		dTrans[1 ][0] = -1;  // sets initial state of DFA to a final state
        		break;
        	}
        }
        que.add(V);
        dfaStates.add(V);
        int row;
        while (!que.isEmpty()) {
            T = que.remove();
            row = getIndex(dfaStates, T);
            for (int i = Dfa.SIGMA_LOWER; i < Dfa.SIGMA_UPPER; i++) {
                char inputSymbol = (char) i;
                HashSet<NfaState> move = Move(T, inputSymbol);
                V = e_Closure(move);
                if (!V.isEmpty()) {
                    if (getIndex(dfaStates, V) == -1) {//!que.contains(V)&& !dfaStates.contains(V)
                        que.add(V);
                        dfaStates.add(V);
                        dTrans[row][i] = dfaStates.size();
                        for (NfaState Vi : V) {
                            if (Vi.getSymbol() == NfaState.ACCEPT || Vi.getSymbol2() == NfaState.ACCEPT) {  // checks if the current NfaState contains a final state
                                dTrans[dfaStates.size()][0] = -1;  // sets the appropriate state in the DFA to a final state
                                break;
                            }
                        }
                    } else 
                        dTrans[row][i] = getIndex(dfaStates, V);
                }
            }
        }
        ArrayList<HashSet<NfaState>> s = new ArrayList<>();
        s.addAll(dfaStates);
        return new Dfa(dTrans, s, s.size());
    }
    
    public int[][] getDTrans() { return dTrans; }
    
    public LinkedHashSet<HashSet<NfaState>> getDfaStates() { return dfaStates; }

}